<?php $__env->startSection('task','Tolong tampilkan nama, email, nomor telefon,wilayah tempat tinggal dan universitas untuk anak-anak yang berkuliah di Institut Teknologi Sepuluh Nopember dan Fakultas Computer Science!'); ?>

<?php $__env->startSection('content'); ?>
<table id="example" class="table table-striped table-bordered table-active" style="width:100%">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama</th>
                <th>Email</th>
                <th>No.Telpon</th>
                <th>Tempat Tinggal</th>
                <th>Universitas</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $L5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no); ?><?php $no++;?></td>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->email); ?></td>
                <td><?php echo e($data->phone_number); ?></td>
                <td><?php echo e($data->kota); ?></td>
                <td><?php echo e($data->university_name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\composer\Latihan1_AMBIZ\resources\views/Latihan5.blade.php ENDPATH**/ ?>