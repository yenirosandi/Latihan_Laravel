<?php $__env->startSection('task','Jumlah Users lulusan tahun 2020-2021 pada wilayah pulau Jawa saja adalah...'); ?>

<?php $__env->startSection('content'); ?>
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Tahun Lulus</th>
                <th>Jumlah User</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $L1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->year_of_graduation); ?></td>
                <td><?php echo e($data->total); ?> orang</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\composer\Latihan1_AMBIZ\resources\views/latihan1.blade.php ENDPATH**/ ?>