<?php $__env->startSection('task','Anak-anak AMBIZ itu paling banyak datang dari universitas apa ya? Coba tolong tampilkan 10 TOP UNIVERSITIES dengan jumlah anak2nya!'); ?>

<?php $__env->startSection('content'); ?>
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>No.</th>
                <th>10 TOP UNIVERSITIES</th>
                <th>Jumlah User</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $L4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no); ?><?php $no++;?></td>
                <td><?php echo e($data->university_name); ?></td>
                <td><?php echo e($data->total); ?> orang</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\composer\Latihan1_AMBIZ\resources\views/Latihan4.blade.php ENDPATH**/ ?>